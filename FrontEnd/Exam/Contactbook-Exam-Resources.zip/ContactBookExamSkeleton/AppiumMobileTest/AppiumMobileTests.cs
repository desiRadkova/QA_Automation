

namespace AppiumMobileTests
{
    public class AppiumMobileTests
    {
        
    }
}